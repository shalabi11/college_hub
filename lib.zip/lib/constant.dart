import 'package:flutter/material.dart';

const kPrimaryBlue = Color(0xFF3B82F6); // لون أزرق أساسي مشابه للمستخدم في HTML
const kLightBlueBackground = Color(0xFFECF4FF);
const kCardBorder = Color(0xFFE5E7EB);
const kTextColor = Color(0xFF374151);
const kTextLight = Color(0xFF6B7280);
const String logo = 'assete/image/logo3.png';
const Icon logos = Icon(Icons.person_2_outlined);
